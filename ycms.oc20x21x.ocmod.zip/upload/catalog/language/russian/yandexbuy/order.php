<?php
$_['text_marketcpa_changeorder']				= "Яндекс.Маркет перевел заказ в %s.";
$_['text_marketcpa_toprocessing']				= "Вы можете поменять его на DELIVERY (до 7 дней) или на CANCELLED";
$_['text_marketcpa_todelivery']				= "Вы можете поменять его на PICKUP (заказ в точке самовывоза) или на DELIVERED (заказ вручен покупателю).";