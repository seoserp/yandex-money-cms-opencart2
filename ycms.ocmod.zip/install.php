<?php
if (version_compare(VERSION, "2.3.0", '>=')){
    throw new Exception("This module developed for Opencart 2.0.x - 2.2.x");
}
?>