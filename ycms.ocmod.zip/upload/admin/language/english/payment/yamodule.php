<?php
// Heading
$_['heading_title']					= 'Библиотека для Y.CMS OpenCart2';